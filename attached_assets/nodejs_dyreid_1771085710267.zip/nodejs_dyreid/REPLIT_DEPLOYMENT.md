# REPLIT DEPLOYMENT - NODE.JS/TYPESCRIPT VERSION

## 🎯 RIKTIG VERSJON FOR DEG!

Du bruker **TypeScript/Node.js** i Replit - dette er 100% kompatibelt! ✅

---

## ⚡ QUICK START (2 MINUTTER)

### Steg 1: Last opp til Replit (30 sek)

I din eksisterende Replit (hvor Training Agent er):

1. **Opprett mappe**: `customer-agent/`
2. **Last opp** alle filer fra denne pakken
3. **Strukturen blir**:
   ```
   din-replit/
   ├── training-agent/    # Eksisterende (TypeScript)
   └── customer-agent/    # NY! ⭐ (TypeScript)
       ├── src/
       ├── public/
       ├── package.json
       └── tsconfig.json
   ```

### Steg 2: Installer dependencies (30 sek)

Shell i Replit:
```bash
cd customer-agent
npm install
```

### Steg 3: OpenAI API Key (30 sek)

Replit Secrets (🔒):
```
OPENAI_API_KEY=sk-proj-...
```

Få key fra: https://platform.openai.com/api-keys

### Steg 4: Kjør! (30 sek)

```bash
npm run dev
```

Replit åpner automatisk webview! ✨

---

## 📦 FILSTRUKTUR

```
customer-agent/
├── src/
│   └── server.ts          # Express server med OpenAI
├── public/
│   └── index.html         # Chat UI
├── package.json           # Dependencies
├── tsconfig.json          # TypeScript config
├── .env.example           # Environment variables template
└── .replit                # Replit config
```

---

## 🚀 TESTING

### Test 1: Enkelt spørsmål
```
Du: Hva koster eierskifte?
Bot: [Instant svar med quick match]
Badge: ⚡ Instant ($0 kostnad!)
```

### Test 2: Medium spørsmål
```
Du: Hvordan aktiverer jeg QR Tag?
Bot: [GPT-4o mini - 1-2 sek]
Badge: ✨ Mini ($0.0004)
```

### Test 3: OTP-login
```
Du: [Klikk "Logg inn"]
Skriv: 12345678
Bot: Jeg har sendt OTP...
Du: [OTP-kode]
Bot: Velkommen, Gudbrand! Jeg ser du har 2 dyr...
Badge: 🧠 GPT-4o
```

---

## 💰 KOSTNADER

### Smart routing i aksjon (1000 meldinger/mnd):

```
700 quick match (instant): $0.00
200 GPT-4o mini:           $0.08
100 GPT-4o:                $0.60
────────────────────────────────
Total:                     $0.68/mnd ✅
```

**Sammenligning:**
- Claude Sonnet: $9.00/mnd
- Bare GPT-4o: $6.00/mnd
- **Smart routing: $0.68/mnd** ⭐

**Besparelse: 92% vs Claude!** 🎉

---

## 🔧 SCRIPTS

```bash
# Development (auto-restart ved endringer)
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Watch TypeScript compilation
npm run watch
```

---

## 🎨 FORBEDRINGER

### Legg til flere quick patterns:

I `src/server.ts`, finn `QUICK_PATTERNS` og legg til:

```typescript
veterinar: {
  regex: /veterinær|dyrelege|klinikk/i,
  response: `**Veterinærregistrering:**
  
Hjelp til å registrere eller endre veterinærklinikk...`
}
```

### Juster model routing:

```typescript
// Mer aggressiv mini-bruk (billigere):
const isShort = message.length < 200; // var 150

// Eller: bruk ALLTID mini (90% billigere)
return 'gpt-4o-mini';
```

---

## 📊 INTEGRASJON MED TRAINING AGENT

### Bruk playbook fra Training Agent:

```typescript
// I src/server.ts:
import playbook from '../training-agent/playbook.json';

function quickIntentMatch(message: string) {
  // First check static patterns
  const staticMatch = checkStaticPatterns(message);
  if (staticMatch) return staticMatch;
  
  // Then check playbook
  for (const entry of playbook) {
    if (entry.keywords.some(kw => message.toLowerCase().includes(kw))) {
      return {
        response: entry.resolution_steps,
        model: 'playbook'
      };
    }
  }
  
  return null;
}
```

---

## 🚀 DEPLOYMENT TIL PRODUKSJON

### Option 1: Replit Deployments (anbefalt)

1. **Klikk "Deploy"** i Replit
2. **Velg "Autoscale"**
3. **Konfigurer**:
   - Build command: `npm run build`
   - Run command: `npm start`
4. **Få URL**: `https://your-app.repl.co`

**Kostnad:**
- Free tier: 100% uptime, 500MB RAM
- Autoscale ($7/mnd): Auto-scaling, bedre ytelse

### Option 2: Custom Domain

```
support.dyreid.no → Replit deployment
```

1. Kjøp domene
2. Replit → Deployments → Custom Domain
3. Legg til DNS records (CNAME)
4. Ferdig!

---

## 🐛 FEILSØKING

### "Cannot find module 'openai'"
```bash
npm install
```

### "Error: OPENAI_API_KEY is not set"
- Sjekk at key er lagt til i Replit Secrets
- Restart server

### "CORS error" (OTP)
- Deploy til produksjon (ikke localhost)
- Min Side blokkerer localhost requests

### "Port 5000 already in use"
```typescript
// I server.ts:
const PORT = process.env.PORT || 3000;
```

### TypeScript compilation errors
```bash
npm run build
# Fix errors, then:
npm run dev
```

---

## 📈 YTELSESOPTIMALISERING

### 1. Cache AI responses

```typescript
import NodeCache from 'node-cache';

const cache = new NodeCache({ stdTTL: 3600 }); // 1 hour

async function getCachedResponse(message: string, userId: string) {
  const key = `${userId}:${message.toLowerCase()}`;
  
  const cached = cache.get(key);
  if (cached) return cached;
  
  const response = await getAIResponse(message);
  cache.set(key, response);
  
  return response;
}
```

### 2. Rate limiting

```typescript
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20 // max 20 requests per minute
});

app.use('/api/chat', limiter);
```

### 3. Compress responses

```typescript
import compression from 'compression';

app.use(compression());
```

---

## ✅ SJEKKLISTE

Før deployment:

- [ ] `npm install` kjørt
- [ ] OPENAI_API_KEY satt i Secrets
- [ ] `npm run build` kjører uten errors
- [ ] `npm run dev` testes lokalt
- [ ] OTP-flow testet med ekte mobilnummer
- [ ] Quick patterns virker
- [ ] Model badge vises korrekt
- [ ] Deploy til Replit

---

## 🎯 NESTE STEG

### Denne uken:
- [ ] Deploy til Replit
- [ ] Test alle funksjoner
- [ ] Monitor OpenAI kostnader

### Neste uke:
- [ ] Legg til flere quick patterns
- [ ] Integrer med Training Agent playbook
- [ ] Custom domain

### Måned 2:
- [ ] Action execution (faktisk utfør eierskifte)
- [ ] Voice input (Whisper)
- [ ] Fine-tune custom modell

---

**Total tid: 2 minutter!** 🚀
