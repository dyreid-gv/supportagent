// DYREID CUSTOMER SUPPORT AGENT - NODE.JS/TYPESCRIPT VERSION
// For Replit med Express + OpenAI + Sessions

import express, { Request, Response } from 'express';
import session from 'express-session';
import cors from 'cors';
import axios from 'axios';
import OpenAI from 'openai';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 5000;

// OpenAI setup
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.use(session({
  secret: process.env.SESSION_SECRET || 'dyreid-secret-change-this',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true in production with HTTPS
}));

// Extend session type
declare module 'express-session' {
  interface SessionData {
    authenticated?: boolean;
    userContext?: any;
    pendingContact?: string;
    awaitingOtp?: boolean;
    aspSession?: string;
  }
}

// Quick intent patterns (instant responses, no AI call!)
const QUICK_PATTERNS = {
  eierskifte: {
    regex: /eierskift|selge|solgt|ny eier|overfør|kjøpt/i,
    response: `**Eierskifte av dyr:**

1. Logg inn på Min Side
2. Velg dyret som skal overføres
3. Klikk "Overfør eierskap"
4. Oppgi ny eiers mobilnummer
5. Ny eier bekrefter via SMS
6. Betal 676 kr (dere får betalingslink)

Prosessen tar vanligvis 1-2 dager. Vil du at jeg logger deg inn for å hjelpe?`
  },
  login: {
    regex: /logg inn|passord|bankid|innlogg|glemt passord/i,
    response: `**Innlogging til Min Side:**

Du kan logge inn med:
- BankID (anbefalt)
- OTP (engangskode til mobil/e-post)

Har du glemt passord? Klikk "Glemt passord" på innloggingssiden.

Vil du at jeg logger deg inn med OTP nå?`
  },
  qr: {
    regex: /qr.?tag|qr.?brikke|skann|aktivere tag/i,
    response: `**QR Tag:**

For å aktivere QR Tag:
1. Logg inn på Min Side
2. Gå til "Mine produkter"
3. Klikk "Aktiver QR Tag"
4. Skann QR-koden eller skriv inn koden
5. Koble til ditt dyr

Har du ikke kjøpt QR Tag ennå? Den koster 199 kr og gir Premium-funksjoner i 1 år!`
  },
  savnet: {
    regex: /savnet|mistet|funnet|borte|forsvunnet/i,
    response: `**Melde dyr savnet:**

1. Logg inn på Min Side
2. Velg dyret
3. Klikk "Meld savnet"
4. Varsling aktiveres automatisk

Hvis noen finner dyret og skanner QR-taggen, får du umiddelbar beskjed!

Skal jeg logge deg inn så vi kan melde dyret savnet?`
  },
  pris: {
    regex: /pris|kost|betale|gratis|abonnement/i,
    response: `**Priser DyreID:**

**Registrering:** 676 kr (engangsgebyr)
**Eierskifte:** 676 kr (per overføring)
**QR Tag Basic:** 199 kr (1 års Premium inkludert)
**QR Tag Premium:** 299 kr/år (fornyelse)
**Smart Tag:** 599 kr
**App DyreID+:** 149 kr/år

Gratis funksjoner: Grunnleggende profil, søk i register, savnet-varsling (uten QR)`
  },
  app: {
    regex: /app|laste ned|installere|dyreid\+/i,
    response: `**DyreID-appen:**

Last ned:
- iOS: App Store (søk "DyreID")
- Android: Google Play (søk "DyreID")

**Gratis versjon:**
- Se dine dyr
- Grunnleggende profil
- Motta varsler

**DyreID+ (149 kr/år):**
- GPS-sporing (med Smart Tag)
- Veterinærjournal
- Vaksinasjonsplan
- Deling med familie`
  }
};

// Quick intent matching
function quickIntentMatch(message: string) {
  const lowerMsg = message.toLowerCase();
  
  for (const [intent, config] of Object.entries(QUICK_PATTERNS)) {
    if (config.regex.test(lowerMsg)) {
      return {
        intent,
        response: config.response,
        model: 'quick-match'
      };
    }
  }
  
  return null;
}

// Smart model selection
function selectOptimalModel(message: string, hasContext: boolean): string {
  const simplePatterns = [
    /pris|kostnad|betale|gratis/i,
    /hvordan|hva er|hva koster/i,
    /åpningstid|telefon|kontakt/i,
    /eierskifte|registrer|aktiver/i
  ];
  
  const isSimple = simplePatterns.some(p => p.test(message));
  const isShort = message.length < 150;
  
  // Use mini if: simple question, no context needed, short message
  if (isSimple && !hasContext && isShort) {
    return 'gpt-4o-mini'; // 90% billigere!
  }
  
  return 'gpt-4o';
}

// Get AI response
async function getAIResponse(message: string, userContext: any = null) {
  // Check quick match first (instant, free!)
  const quickMatch = quickIntentMatch(message);
  if (quickMatch) {
    return quickMatch;
  }
  
  // Determine model
  const hasContext = userContext !== null;
  const model = selectOptimalModel(message, hasContext);
  
  // Build system prompt
  let systemPrompt = '';
  if (userContext) {
    const petsStr = userContext.Pets?.map((p: any) => `${p.Name} (${p.Species})`).join(', ') || 'ingen';
    systemPrompt = `Du er DyreID supportagent.

BRUKERINFO:
Navn: ${userContext.FirstName || 'ukjent'}
Registrerte dyr: ${petsStr}

Bruk denne informasjonen til å gi personlige, hjelpsome svar.
Vær vennlig, profesjonell og proaktiv.
Svar ALLTID på norsk (bokmål).`;
  } else {
    systemPrompt = `Du er DyreID supportagent.
Hjelp med eierskifte, registrering, produkter og app.
Vær vennlig og profesjonell.
Svar ALLTID på norsk (bokmål).`;
  }
  
  try {
    const completion = await openai.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      temperature: 0.7,
      max_tokens: 500
    });
    
    return {
      response: completion.choices[0].message.content,
      model: model
    };
  } catch (error) {
    console.error('OpenAI error:', error);
    return {
      response: '❌ Beklager, jeg hadde problemer med å svare. Prøv igjen.',
      model: 'error'
    };
  }
}

// OTP functions
async function sendOTP(contactMethod: string): Promise<boolean> {
  try {
    const response = await axios.post(
      'https://minside.dyreid.no/Security/SendOtp',
      { contactMethod },
      { timeout: 10000 }
    );
    
    return response.status === 200;
  } catch (error) {
    console.error('Send OTP error:', error);
    return false;
  }
}

async function verifyOTP(otpCode: string, contactMethod: string) {
  try {
    // Verify OTP
    const verifyResponse = await axios.post(
      'https://minside.dyreid.no/Security/ValidateOtp',
      { contactMethod, otpCode },
      { timeout: 10000 }
    );
    
    if (verifyResponse.status !== 200) {
      return {
        success: false,
        message: '❌ Feil OTP-kode. Prøv igjen.'
      };
    }
    
    // Get session cookie
    const sessionCookie = verifyResponse.headers['set-cookie']?.find(c => c.includes('ASP.NET_SessionId'));
    
    if (!sessionCookie) {
      return {
        success: false,
        message: '❌ Kunne ikke hente session'
      };
    }
    
    // Fetch user context
    const userResponse = await axios.get(
      `https://minside.dyreid.no/Security/GetOwnerDetailforOTPScreen?emailOrContactNumber=${contactMethod}`,
      {
        headers: { Cookie: sessionCookie },
        timeout: 10000
      }
    );
    
    if (userResponse.status !== 200) {
      return {
        success: false,
        message: '❌ Kunne ikke hente brukerdata'
      };
    }
    
    const userData = userResponse.data;
    const petsCount = userData.Pets?.length || 0;
    const petsStr = userData.Pets?.map((p: any) => `• ${p.Name} (${p.Species})`).join('\n') || '';
    
    return {
      success: true,
      message: `✅ Velkommen, ${userData.FirstName || 'bruker'}!

Jeg ser du har **${petsCount} registrerte dyr**:
${petsStr}

Hvordan kan jeg hjelpe deg i dag?`,
      userContext: userData,
      sessionCookie
    };
  } catch (error) {
    console.error('Verify OTP error:', error);
    return {
      success: false,
      message: '❌ Kunne ikke verifisere OTP'
    };
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.post('/api/chat', async (req: Request, res: Response) => {
  const { message } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Tom melding' });
  }
  
  // Check if awaiting OTP
  if (req.session.awaitingOtp) {
    const contactMethod = req.session.pendingContact;
    
    if (!contactMethod) {
      return res.json({
        response: '❌ Ingen ventende OTP-forespørsel',
        model: 'error'
      });
    }
    
    // User is entering OTP code
    const result = await verifyOTP(message.trim(), contactMethod);
    
    if (result.success) {
      req.session.awaitingOtp = false;
      req.session.authenticated = true;
      req.session.userContext = result.userContext;
      req.session.aspSession = result.sessionCookie;
      
      // Generate suggestions
      const suggestions = [];
      if (result.userContext?.Pets) {
        for (const pet of result.userContext.Pets.slice(0, 2)) {
          suggestions.push({
            message: `Har ${pet.Name} QR Tag for enklere gjenfinning?`,
            action: 'Bestill QR Tag (199 kr)'
          });
        }
      }
      
      return res.json({
        response: result.message,
        model: 'otp-verify',
        suggestions
      });
    } else {
      return res.json({
        response: result.message,
        model: 'otp-verify'
      });
    }
  }
  
  // Get AI response
  const userContext = req.session.userContext;
  const result = await getAIResponse(message, userContext);
  
  res.json({
    response: result.response,
    model: result.model
  });
});

app.post('/api/request-login', async (req: Request, res: Response) => {
  const { contact_method } = req.body;
  
  if (!contact_method || !contact_method.trim()) {
    return res.status(400).json({ error: 'Mangler mobilnummer/e-post' });
  }
  
  const success = await sendOTP(contact_method);
  
  if (success) {
    req.session.pendingContact = contact_method;
    req.session.awaitingOtp = true;
    
    return res.json({
      success: true,
      message: `📱 Jeg har sendt en engangskode til **${contact_method}**. Vennligst skriv inn koden.`
    });
  } else {
    return res.json({
      success: false,
      message: '❌ Kunne ikke sende OTP. Sjekk at mobilnummer/e-post er riktig.'
    });
  }
});

app.post('/api/logout', (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout feilet' });
    }
    res.json({ success: true });
  });
});

app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    authenticated: req.session.authenticated || false,
    userContext: req.session.authenticated ? req.session.userContext : null
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 DyreID Support Agent kjører på port ${PORT}`);
  console.log(`📱 Åpne http://localhost:${PORT} for å teste`);
});
